const int MAX_LVL = 100;
const int MAX_MAS = 15000;
const int AURS_RADIUS = 1;
#define MAX_DATA 999;